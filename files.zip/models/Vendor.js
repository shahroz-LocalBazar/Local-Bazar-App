const mongoose = require('mongoose');
const vendorSchema = new mongoose.Schema({
  shopName: String,
  ownerName: String,
  email: { type: String, unique: true },
  password: String,
  address: String,
  products: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
  paymentDetails: Object,
});
module.exports = mongoose.model('Vendor', vendorSchema);