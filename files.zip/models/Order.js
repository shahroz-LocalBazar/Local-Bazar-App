const mongoose = require('mongoose');
const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' },
  products: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    quantity: Number,
  }],
  status: { type: String, default: 'Pending' },
  address: String,
  totalPrice: Number,
  paymentStatus: String,
  placedAt: { type: Date, default: Date.now },
  deliveredAt: Date,
});
module.exports = mongoose.model('Order', orderSchema);